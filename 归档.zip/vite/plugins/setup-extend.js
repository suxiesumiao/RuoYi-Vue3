import setupExtend from 'vite-plugin-vue-setup-extend'

export default function createSetupExtend() {
    return setupExtend()
}
